export const environment = {
  production: false,
  apiEndpoint: "http://localhost:8081/"
};
