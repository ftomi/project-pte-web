import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-container',
  templateUrl: './register-container.component.html',
  styleUrls: ['./register-container.component.scss']
})
export class RegisterContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
